Python 3.12.3 (tags/v3.12.3:f6650f9, Apr  9 2024, 14:05:25) [MSC v.1938 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.

= RESTART: C:\Users\pvenk\OneDrive\Documents\Desktop\STA PROJECT\SHOPPER TREND ANALYSIS.py
Enter item names: apple mango papaya grapes oil chocolate biscuits
Enter item quantities: 5 6 7 8 4 3 2
Enter item prices: 20 30 25 40 35 50 55
Enter item availability (yes/no): yes yes yes yes yes yes yes
Item Name           Item Quantity  Item PriceAvailability   
apple               5              20.0      yes            
mango               6              30.0      yes            
papaya              7              25.0      yes            
grapes              8              40.0      yes            
oil                 4              35.0      yes            
chocolate           3              50.0      yes            
biscuits            2              55.0      yes            

Billed Items:
1. apple
2. mango
3. papaya
4. grapes
5. oil
6. chocolate
7. biscuits
Enter item number or 'done': 1
Added apple to the bill.
Enter item number or 'done': 2
Added mango to the bill.
Enter item number or 'done': 3
Added papaya to the bill.
Enter item number or 'done': 4
Added grapes to the bill.
Enter item number or 'done': 5
Added oil to the bill.
Enter item number or 'done': 6
Added chocolate to the bill.
Enter item number or 'done': 7
Added biscuits to the bill.
Enter item number or 'done': done

Final Bill:
Item Name           Item Quantity  Item PriceAvailability   
apple               5              20.0      yes            
mango               6              30.0      yes            
papaya              7              25.0      yes            
grapes              8              40.0      yes            
oil                 4              35.0      yes            
chocolate           3              50.0      yes            
biscuits            2              55.0      yes            

Total Amount: 1175.00
GST (18%): 176.25
Discount (15%): 235.00
Final Amount: 1116.25
